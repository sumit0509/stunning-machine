package com.UserDetails.UserDetails.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.UserDetails.UserDetails.Entity.UserEntity;
import com.UserDetails.UserDetails.Repository.UserDetailsRepo;
import com.UserDetails.UserDetails.ServiceImpl.UserByAttribute;
import com.UserDetails.UserDetails.UserException.UserNotFoundException;

import java.util.Optional;

import javax.validation.Valid;

@RestController
public class UserDetailsController {

	@Autowired
	private UserDetailsRepo userDetailsRepo;
	
	@Autowired
	private UserByAttribute userByAttribute;
	
	
	@GetMapping("/allUser")
	public List<UserEntity> getAllUsers(){
		
		return userDetailsRepo.findAll();
		
	}
	@GetMapping("/sortUserByDob")
public List<UserEntity> sortUserByDob(){
	
	List<UserEntity> userEntities=userDetailsRepo.findAll(Sort.by("dob").descending());
	
	return userEntities;
	
}
	@GetMapping("/sortUserByDoj")
public List<UserEntity> sortUserByDoj(){
	
	List<UserEntity> userEntities=userDetailsRepo.findAll(Sort.by("joiningDate").descending());
	
	return userEntities;
	
}
	
	@PostMapping("/saveUser")
	public ResponseEntity<Object> saveUserDetails(@Valid @RequestBody UserEntity userEntity){
		
		
		try {
			
			UserEntity _userEntity=userDetailsRepo.save(userEntity);
			
			return new ResponseEntity<>(HttpStatus.CREATED);
			
		} catch (Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
			
	}	
	
	
	/*@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	}*/
/*
@PutMapping("/userUpdate/{id}")	
public ResponseEntity<UserEntity> updateUserDetails(@PathVariable("id") long id, @RequestBody UserEntity userEntity){
	
	Optional<UserEntity> user=userDetailsRepo.findById(id);
	
	if(user.isPresent()) {
		
		UserEntity usEntity=user.get();
		usEntity.setfName(userEntity.getfName());
		usEntity.setlName(userEntity.getlName());
		usEntity.setPinCode(userEntity.getPinCode());
		usEntity.setDob(userEntity.getDob());
		usEntity.setJoiningDate(userEntity.getJoiningDate());
		return new ResponseEntity<>(userDetailsRepo.save(userEntity),HttpStatus.NOT_FOUND);
	}
	
	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		
	}*/
	

@PutMapping("/userUpdate/{id}")	
public ResponseEntity<UserEntity> updateEmployee(@PathVariable(value = "id") long employeeId,
  @Valid @RequestBody UserEntity userEntity) throws UserNotFoundException {
	UserEntity usEntity = userDetailsRepo.findById(employeeId)
     .orElseThrow(() -> new UserNotFoundException("Employee not found for this id :: " + employeeId));

     usEntity.setfName(userEntity.getfName());
		usEntity.setlName(userEntity.getlName());
		usEntity.setPinCode(userEntity.getPinCode());
		usEntity.setDob(userEntity.getDob());
		usEntity.setJoiningDate(userEntity.getJoiningDate());
     final UserEntity updatedEmployee = userDetailsRepo.save(userEntity);
     return ResponseEntity.ok(updatedEmployee);
}
	
	
	@GetMapping("/userById/{id}")
	public Optional<UserEntity> findUserById(@PathVariable long id) {
	
		
		Optional<UserEntity> user=userDetailsRepo.findById(id);
		
		if(!user.isPresent()){
			
			try {
				throw new UserNotFoundException("id" +id);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return user;
		
	}
	
	

	@GetMapping("/userByName/{name}")
	public List<UserEntity> findUserByName(@PathVariable String name) {
	
		
		List<UserEntity> userValue=userByAttribute.findByAttribute(UserEntity.class, "fName", name);
		
		if(!userValue.isEmpty()){
			
			try {
				throw new UserNotFoundException("id" +name);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//String user=userValue.get(0).toString();
		
		return userValue;
		
	}
	
	
	@GetMapping("/userByLastName/{name}")
	public List<UserEntity> findUserLastName(@PathVariable String name) {
	
		
		List<UserEntity> userValue=userByAttribute.findByAttribute(UserEntity.class, "lName", name);
		
		if(!userValue.isEmpty()){
			
			try {
				throw new UserNotFoundException("id" +name);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//String user=userValue.get(0).toString();
		
		return userValue;
		
	}
	
	@GetMapping("/userByPincode/{id}")
	public List<UserEntity> findUserLastName(@PathVariable int id) {
	
		
		List<UserEntity> userValue=userByAttribute.findByAttribute(UserEntity.class, "pinCode", id);
		
		if(!userValue.isEmpty()){
			
			try {
				throw new UserNotFoundException("id" +id);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//String user=userValue.get(0).toString();
		
		return userValue;
		
	}
	
	
	@DeleteMapping("/user/{id}")
	public void deleteUser(@PathVariable long id) {
		
		userDetailsRepo.deleteById(id);
		
		
	}
	
	@DeleteMapping("/deleteAll")
	public ResponseEntity<HttpStatus> deleteAllUsers() {
		try {
			
			userDetailsRepo.deleteAll();
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
}
