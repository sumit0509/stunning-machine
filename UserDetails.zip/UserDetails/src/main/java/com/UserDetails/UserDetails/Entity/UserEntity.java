package com.UserDetails.UserDetails.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Entity
@Table(name="User_Details")
public class UserEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "generator")
	@TableGenerator(name = "generator", initialValue = 1000, allocationSize = 1)
	
	private Long eId;
	
	@NotBlank
	@Size(min=2,message="Name should have atleast 2 characters")
	private String fName;
	@NotBlank
	@Size(min=2,message="Last Name should have atleast 2 characters")
	private String lName;
	@NotNull(message="Pin Code Should Not Be Null")
	private int pinCode;
	@NotNull(message="DOB Should Not Be Null")
	private Date dob;
	@NotNull(message="DOJ Should Not Be Null")
	private Date joiningDate;
	
	public UserEntity(Long eId, String fName, String lName, int pinCode, Date dob, Date joiningDate) {
		super();
		this.eId = eId;
		this.fName = fName;
		this.lName = lName;
		this.pinCode = pinCode;
		this.dob = dob;
		this.joiningDate = joiningDate;
	}
	
	public UserEntity() {}

	public Long geteId() {
		return eId;
	}

	public void seteId(Long eId) {
		this.eId = eId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	
	
	
	
}
