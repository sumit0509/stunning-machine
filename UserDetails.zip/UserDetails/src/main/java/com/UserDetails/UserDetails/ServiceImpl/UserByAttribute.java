package com.UserDetails.UserDetails.ServiceImpl;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserByAttribute {

	@Autowired
	EntityManager entityManager;
	
	public <T> List<T> findByAttribute(final Class<T> entityClass, final String attributeName,
			final Object attributeValue) {
		if (null == entityClass)
			throw new IllegalArgumentException("entityClass can't be null");
		if (null == attributeName)
			throw new IllegalArgumentException("attributeName can't be null");
		if (null == attributeValue)
			throw new IllegalArgumentException("attributeValue can't be null");

		return castResultList(entityManager
				.createQuery("select e from " + entityClass.getSimpleName() + " e where e." + attributeName + " = ?1")
				.setParameter(1, attributeValue).getResultList());
	
}
	//used for casting Result set into list
	@SuppressWarnings("unchecked")
	private <T> List<T> castResultList(List<?> results) {
		return (List<T>) results;
	}
}