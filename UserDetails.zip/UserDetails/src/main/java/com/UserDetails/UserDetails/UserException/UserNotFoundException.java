package com.UserDetails.UserDetails.UserException;

public class UserNotFoundException extends Exception {

	public UserNotFoundException (String str) {
		
		super(str);
	}
	
}
